package in.ineuron.main;

public class TestApp {
	public static void main(String[] args) {

		Student student = new Student("sachin", 50, 10);
		System.out.println(student);

	}
}
