package in.ineuron.bean;

//Dependent Object
public class Employee {

	 String eid;
	 String ename;
	 String eaddr;
	 
	public Employee(String eid, String ename, String eaddr) {
		this.eid = eid;
		this.ename = ename;
		this.eaddr = eaddr;
	}
	 
	 

	
}
